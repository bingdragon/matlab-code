function [r,y1] = mising_r( pr,n,y)
r=zeros(n,1);
y1=y;
for i=1:n
     u2=unifrnd(0,1);
     if u2<=pr(i);
         r(i)=1;
         y1(i)=0.9*y(i);
       
     end
end

