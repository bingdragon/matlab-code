function y1= sample_ymis(y0,r,mu_t1,sigma2_t1,n ,varphi_t0)
y1=y0;

for i=1:n
    if r(i)==1
        Gyy=[1;y0(i)];%%%%%%%��ĸ����
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������ѡֵ
           y1_zj= exprnd(y0(i),1,1);
            y_fz1=exppdf(y0(i),y1_zj);
            y_fm1=exppdf(y1_zj,y0(i));
            Gy0=[1;y1_zj];%%%%%%%%%%%%%%%%%%���ӵ���
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���������
           y_fz2=lognpdf(y1_zj,mu_t1,sqrt(sigma2_t1))*(logncdf(y1_zj,mu_t1,sqrt(sigma2_t1)))^(i-1)*(1-logncdf(y1_zj,mu_t1,sqrt(sigma2_t1)))^(n-i);
           y_fz2=y_fz2*exp(varphi_t0*Gy0-log(1+exp(varphi_t0*Gy0)));
           y_fm2=lognpdf(y0(i),mu_t1,sqrt(sigma2_t1))*(logncdf(y0(i),mu_t1,sqrt(sigma2_t1)))^(i-1)*(1-logncdf(y0(i),mu_t1,sqrt(sigma2_t1)))^(n-i);
           y_fm2=y_fm2*exp(varphi_t0*Gyy-log(1+exp(varphi_t0*Gyy)));
           arf_y1=y_fz1*y_fz2/y_fm1/y_fm2;
           arf_ymis=min(1,arf_y1);
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��������ֵ
           u=unifrnd(0,1);
           if u<=arf_ymis
               y1(i)=y1_zj;
           end
           
    end
end


end

