function [varphi_t1,number_varphi]= sample_varphi(varphi_t0,varphi0,y1,r,n,H_0varphi,sigma2_varphi,number_varphi)
Gyy0=[ones(1,n);y1'];
Gyi=zeros(2,2);
for i=1:n
    Gyi=Gyi+Gyy0(:,i)*Gyy0(:,i)';
end
    Gyi=0.25*Gyi+inv(H_0varphi);
    omiga_varphi=sigma2_varphi*inv(Gyi);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������ѡֵ
    varphit0=mvnrnd(varphi_t0,omiga_varphi);
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������������
    fvarphi_fz=0;
    fvarphi_fm=0;
    for i=1:n
        fvarphi_fz=fvarphi_fz+r(i)*varphit0*Gyy0(:,i)-log(1+exp(varphit0*Gyy0(:,i)));
        fvarphi_fm=fvarphi_fm+r(i)*varphi_t0*Gyy0(:,i)-log(1+exp(varphi_t0*Gyy0(:,i)));
    end
    fvarphi_fz=fvarphi_fz-0.5*(varphit0-varphi0)*inv(H_0varphi)*(varphit0-varphi0)';
    fvarphi_fm=fvarphi_fm-0.5*(varphi_t0-varphi0)*inv(H_0varphi)*(varphi_t0-varphi0)';
    arf_varphi1=exp(fvarphi_fz-fvarphi_fm);
    arf_varphi=min(1,arf_varphi1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��������ֵ
    u=unifrnd(0,1);
    if u<=arf_varphi
       varphi_t1=varphit0;
       number_varphi=number_varphi+1;
    else
    varphi_t1=varphi_t0;
    end

end

