function Q_theta = compu_Q( mu_t1,sigma2_t1,y,n)
Q_theta=1;
for i=1:n
    Q_theta=Q_theta*logncdf(y(i),mu_t1,sqrt(sigma2_t1))^(i-1)*(1-logncdf(y(i),mu_t1,sqrt(sigma2_t1)))^(n-i);
end
end

