function [mu_t1,sigma2_t1] = sample_theta( n,k0,mu0,y,sigma20,v0 )
a=k0+n;
b=k0*mu0+sum(log(y));
c=k0*mu0^2+sum(log(y).*log(y));
part1=(v0+n)/2;
part2=(v0*sigma20^2+c-b^2/a)/2;
sigma2_t1=1/gamrnd(part1,1/part2);
mu_t1=mvnrnd(b/a,sqrt(sigma2_t1/a));
end

