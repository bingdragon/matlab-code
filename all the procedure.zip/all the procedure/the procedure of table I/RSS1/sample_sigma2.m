function [sigma2_t1,num_sigma2] = sample_sigma2( k0,mu0,y,n,sigma2_t0,mu_t0,num_sigma2,sigma20,v0,sigma2_sig)
%%%%%%%%%%%%%%%%%%%%%%%%%������ѡֵ
            sigma2_zj=exprnd(sigma2_t0,1,1);
            fsigma_fz=exppdf(sigma2_t0,sigma2_zj);
            fsigma_fm=exppdf(sigma2_zj,sigma2_t0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%���������
fsigma_fz1=1;
fsigma_fm1=1;
for i=1:n
    fsigma_fz1=fsigma_fz1*logncdf(y(i),mu_t0,sqrt(sigma2_zj))^(i-1)*(1-logncdf(y(i),mu_t0,sqrt(sigma2_zj)))^(n-1)*lognpdf(y(i),mu_t0,sqrt(sigma2_zj));
    fsigma_fm1=fsigma_fm1*logncdf(y(i),mu_t0,sqrt(sigma2_t0))^(i-1)*(1-logncdf(y(i),mu_t0,sqrt(sigma2_t0)))^(n-1)*lognpdf(y(i),mu_t0,sqrt(sigma2_t0));
    fsigma_zm1=exp(log()-log());
end
    fsigma_fz2=-(k0*(mu_t0-mu0)^2+v0*sigma20)/(2*sigma2_zj);
    fsigma_fm2=-(k0*(mu_t0-mu0)^2+v0*sigma20)/(2*sigma2_t0);
    fsigma_fmz2=(sigma2_t0/sigma2_zj)^(0.5*(v0+1)+1);
    arfa_sigma1=exp(fsigma_fz2-fsigma_fm2)*fsigma_fz1/fsigma_fm1*fsigma_fmz2*fsigma_fz/fsigma_fm;
    arfa_sigma=min(1,arfa_sigma1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�����µĲ���
    u=unifrnd(0,1);
     if u<=arfa_sigma
             sigma2_t1=sigma2_zj;
             num_sigma2=num_sigma2+1;
     else
             sigma2_t1=sigma2_t0;
    end
end

