function [mu_t1,num_mu] = sample_mu( k0,mu0,y,n,sigma2_t0,mu_t0,sigma2_mu ,num_mu)
%%%%%%%%%%%%%%%%%%%%%%%%%������ѡֵ
% z=normrnd(0,1);
z=randn;
mu_zj=mu_t0+sigma2_mu*z;
%%%%%%%%%%%%%%%%%%%%%%%%%%%���������
fmu_fz1=1;
fmu_fm1=1;
for i=1:n
    fmu_fz1=fmu_fz1*logncdf(y(i),mu_zj,sqrt(sigma2_t0))^(i-1)*(1-logncdf(y(i),mu_zj,sqrt(sigma2_t0)))^(n-i)*lognpdf(y(i),mu_zj,sqrt(sigma2_t0));
    fmu_fm1=fmu_fm1*logncdf(y(i),mu_t0,sqrt(sigma2_t0))^(i-1)*(1-logncdf(y(i),mu_t0,sqrt(sigma2_t0)))^(n-i)*lognpdf(y(i),mu_t0,sqrt(sigma2_t0));
end
    fmu_fz2=-k0*(mu_zj-mu0)^2/(2*sigma2_t0);
    fmu_fm2=-k0*(mu_t0-mu0)^2/(2*sigma2_t0);
    arfa_mu1=exp(fmu_fz2-fmu_fm2)*fmu_fz1/fmu_fm1;
    arfa_mu=min(1,arfa_mu1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�����µĲ���
    u=unifrnd(0,1);
     if u<=arfa_mu
             mu_t1=mu_zj;
             num_mu=num_mu+1;
     else
             mu_t1=mu_t0;
    end
end

