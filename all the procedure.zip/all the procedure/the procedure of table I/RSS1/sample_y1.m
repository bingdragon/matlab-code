function y = sample_y1(mu,sigma2,n)
%  x0=lognrnd(mu,sqrt(sigma2),n,n);
%  x0=normrnd(mu,sqrt(sigma2),n,n);
% x=sort(x0,2);
% y=diag(x);
% y=log(x1);
y=zeros(n,1);
for i=1:n
    x0=lognrnd(mu,sqrt(sigma2),n,1);
     x=sort(x0);
     y(i)=x(i);
end
end

