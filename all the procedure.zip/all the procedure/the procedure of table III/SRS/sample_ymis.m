function y1= sample_ymis(y,r,mu_t1,sigma2_t1,n )
y1=y;
for i=1:n
    if r(i)==1
        y1(i)=lognrnd(mu_t1,sqrt(sigma2_t1),1,1);
        
    end
end


end

