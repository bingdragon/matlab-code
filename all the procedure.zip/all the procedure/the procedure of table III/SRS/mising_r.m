function [r,nur] = mising_r( n,y,nur)
r=zeros(n,1);
pr=mean(y(1:3));
for i=4:n
     u2=normrnd(0,1);
     if u2>pr;
         r(i)=1;
       nur=nur+1;
     end
end

