function r = mising_r( pr,n)
r=zeros(n,1);

for i=1:n
     u2=unifrnd(0,1);
     if u2<=pr;
         r(i)=1;
       
     end
end

