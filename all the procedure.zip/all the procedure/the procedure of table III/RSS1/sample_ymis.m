function y1= sample_ymis(y,r,mu_t1,sigma2_t1,n )
y1=y;
for i=1:n
    if r(i)==1
        x=lognrnd(mu_t1,sqrt(sigma2_t1),n,1);
        x=sort(x);
        y1(i)=x(i);
    end
end


end

